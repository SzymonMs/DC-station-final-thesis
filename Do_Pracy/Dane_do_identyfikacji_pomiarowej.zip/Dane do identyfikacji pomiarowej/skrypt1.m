clc;
clear all
%% prawy kierunek obrot�w
W12vP= load('DanePomiarowe12vP\pomiarW.csv');
W12vP=W12vP(:,2);
W12vP=W12vP(1:781);
W16vP= load('DanePomiarowe16vP\pomiarW.csv');
W16vP=W16vP(:,2);
W16vP=W16vP(1:781);
W20vP= load('DanePomiarowe20vP\pomiarW.csv');
W20vP=W20vP(:,2);

W24vP= load('DanePomiarowe24vP\pomiarW.csv');
t=W24vP(:,1);
t=W24vP(1:781);
W24vP=W24vP(:,2);
W24vP=W24vP(1:781);
% figure
% plot(t,W12vP,t,W16vP,t,W20vP,t,W24vP);
% legend("12V", "16V", "20V", "24V");
% xlabel("time [s]");
% ylabel("n [rpm]");
% title("Prawy kierunek obrot�w")
% kf12p=12/(W12vP(781)*pi/30);
% kf16p=16/(W16vP(781)*pi/30);
% kf20p=20/(W20vP(781)*pi/30);
% kf24p=24/(W24vP(781)*pi/30);

%% lewy kierunek obrt�w
W12vL= load('DanePomiarowe12vL\pomiarW.csv');
W12vL=W12vL(:,2);
W12vL=W12vL(1:778);
W16vL= load('DanePomiarowe16vL\pomiarW.csv');
W16vL=W16vL(:,2);
W16vL=W16vL(1:778);
W20vL= load('DanePomiarowe20vL\pomiarW.csv');
W20vL=W20vL(:,2);
W20vL=W20vL(1:778);
W24vL= load('DanePomiarowe24vL\pomiarW.csv');
t2=W24vL(:,1);
t2=W24vL(1:778);
W24vL=W24vL(:,2);
W24vL=W24vL(1:778);
% figure
% plot(t2,W12vL,t2,W16vL,t2,W20vL,t2,W24vL);
% legend("12V", "16V", "20V", "24V");
% xlabel("time [s]");
% ylabel("n [rpm]");
% title("Lewy kierunek obrot�w")
% kf12L=12/(W12vL(778)*pi/30);
% kf16L=16/(W16vL(778)*pi/30);
% kf20L=20/(W20vL(778)*pi/30);
% kf24L=24/(W24vL(778)*pi/30);

%% Momenty bezw�adnosci (wczytywac odpowiednie pliki, dostosowywac pr�bki do obserwacji)
I12vL= load('DanePomiarowe12vP\pomiarI.csv');
I12vL=I12vL(:,2);
I12vL=I12vL(40:200);
W12vP=W12vP(40:200);
t=t(40:200);
plot(t,W12vP,t,I12vL);
xlabel("time [s]")
ylabel("n [rpm] I [mA]")
legend("n","I")
title(" Wyznaczanie momentu bezw�adno�ci J")
grid on

